package com.qmetry.qaf.example.steps;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class API_TestBase {
	
	// Api key for gitHub
	private static String Access_Token = "Bearer " + "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";
	private static String uri = "https://api.github.com";

	// gets available repository details on GitHub
	public static HttpResponse<String> get_request(String endPoint) {
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = (HttpRequest) HttpRequest.newBuilder().header("Authorization", Access_Token)
				.header("Content-Type", "application/json").uri(URI.create(uri + endPoint)).GET().build();
		HttpResponse<String> response = null;
		try {
			response = client.send(request, BodyHandlers.ofString());
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	// creates new repository in github
	public static HttpResponse<String> post_request(String endPoint, String payload) {

		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = HttpRequest.newBuilder().header("Accept", "application/json")
				.header("Content-Type", "application/json").header("Authorization", Access_Token)
				.uri(URI.create(uri + endPoint)).POST(BodyPublishers.ofString(payload)).build();
		HttpResponse<String> response = null;
		try {
			response = client.send(request, BodyHandlers.ofString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	// updates existing repositry name, note: git hub uses PATCH method for update
	// repo name instead of put
	public static HttpResponse<String> put_request(String endPoint, String payload) {

		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = HttpRequest.newBuilder().header("Authorization", Access_Token)
				.header("Content-Type", "application/json").header("Accept", "application/json")
				.uri(URI.create(uri + endPoint)).method("PATCH", BodyPublishers.ofString(payload)).build();
		HttpResponse<String> response = null;
		try {
			response = client.send(request, BodyHandlers.ofString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;

	}

	// deletes the existing repository 
	public static HttpResponse<String> delete_request(String endPoint) {

		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = HttpRequest.newBuilder().header("Authorization", Access_Token)
				.header("Content-Type", "application/json").uri(URI.create(uri + endPoint)).DELETE().build();
		HttpResponse<String> response = null;
		try {
			response = client.send(request, BodyHandlers.ofString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	// Converts String to JSON Object Array
	public static JSONArray jsonArray_Convertor(String JsonObjectArray) {

		JSONArray objArray = null;
		try {
			objArray = (JSONArray) new JSONParser().parse(JsonObjectArray);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objArray;
	}

	// looping and extracting the data from JSON Object Array
	public static void extractdata_ObjArray(JSONArray jsonArray, String objKey) {

		int index = 0;
		while (index < jsonArray.size()) {
			JSONObject obj = (JSONObject) jsonArray.get(index);
			System.out.println(obj.toJSONString());
			String value = obj.get(objKey).toString();
			System.out.println(objKey + ": " + value);
			index++;
		}
	}

	// Converts String to JSON Object
	public static JSONObject jsonObject_Convertor(String jsonObject) {

		JSONObject obj = null;
		try {
			obj = (JSONObject) new JSONParser().parse(jsonObject);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}

	// stores payload to json format for creating the new repo
	public static String createRepo_Payload(String repoName) {

		JSONObject obj = new JSONObject();
		obj.put("name", repoName);
		obj.put("auto_init", true);
		obj.put("private", false);
		obj.put("gitignore_template", "nanoc");
		return obj.toString();
	}

	// stores the payload to json format for updating repo name
	public static String updateRepo_Payload(String updateName) {

		JSONObject obj = new JSONObject();
		obj.put("name", updateName);
		return obj.toString();

	}
}
