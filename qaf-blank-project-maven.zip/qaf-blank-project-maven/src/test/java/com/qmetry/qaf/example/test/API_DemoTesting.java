package com.qmetry.qaf.example.test;

import java.net.http.HttpResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import com.qmetry.qaf.example.steps.API_TestBase;

import junit.framework.Assert;

public class API_DemoTesting {

	String reponame, updatedReponame;
	
	@Test(priority = 1, enabled = true)
	public void createRepo_Test() {

		reponame = "Repos_ForTesting";
		String payload = API_TestBase.createRepo_Payload(reponame);
		HttpResponse response = API_TestBase.post_request("/user/repos", payload);

		String reponseBody = response.body().toString();
		int statusCode = response.statusCode();

		System.out.println("The status code and response body from post call \n" + statusCode);
		System.out.println(response.body());

		JSONObject obj = API_TestBase.jsonObject_Convertor(reponseBody);
		String createdRepoName = obj.get("name").toString();

		Assert.assertEquals(201, statusCode);
		Assert.assertEquals(reponame, createdRepoName);
	}

	@Test(priority = 2, enabled = false)
	public void getRepos_Test() {

		System.out.println("============================");
		HttpResponse response = API_TestBase.get_request("/users/HCLQA/repos");

		int statusCode = response.statusCode();
		String reponseBody = response.body().toString();
		System.out.println("The status code and response body from get call : " + statusCode);

		JSONArray objArray = API_TestBase.jsonArray_Convertor(reponseBody);
		System.out.println("current object count in array is  " + objArray.size());
		API_TestBase.extractdata_ObjArray(objArray, "name");

		Assert.assertEquals(200, response.statusCode());
	}

	@Test(priority = 3, enabled = false)
	public void updateRepo_Test() {

		System.out.println("============================");
		updatedReponame = "Updated_ReposforTesting";
		String payload = API_TestBase.updateRepo_Payload(updatedReponame);
		HttpResponse response = API_TestBase.put_request("/repos/HCLQA/" + "Repos_ForTesting", payload);

		String body = response.body().toString();
		int statusCode = response.statusCode();

		JSONObject obj = API_TestBase.jsonObject_Convertor(body);
		System.out.println("The stattus code and response from put request : \n" + statusCode + "\n" + obj);
	
		Assert.assertEquals(200, statusCode);
	}

	@Test(priority = 4, enabled = false)
	public void deleteRepo_Test() {

		System.out.println("============================");
		HttpResponse<String> response = API_TestBase.delete_request("/repos/HCLQA/" + "Updated_ReposforTesting");
		int statusCode=response.statusCode();
		
		System.out.println("The status code from delete request \n" + response.statusCode());
		Assert.assertEquals(204, statusCode);
	}

}
